// HELLO WORLD

// Open a terminal.
// The VS Code integrated terminal is nice.
// Run this file with node:
// node exercise00.js

// Confirm that you see the text "Hello World" in the console.

console.log("Hello World");