package learn.safari.domain;

public enum ActionStatus {
    SUCCESS,
    INVALID,
    DUPLICATE,
    NOT_FOUND
}
